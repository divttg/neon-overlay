package com.example.neonoverlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Button

class NeonOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var drawView: DrawView
    private lateinit var button: Button
    private var isDrawing = true

    private val neonColors = listOf(0xFF00FFFF.toInt(), 0xFFFF00FF.toInt(), 0xFF00FF00.toInt())
    private var currentColorIndex = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        drawView = DrawView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(drawView, params)

        button = Button(this).apply { text = "🎨" }
        button.setOnClickListener {
            currentColorIndex = (currentColorIndex + 1) % neonColors.size
            drawView.setPenColor(neonColors[currentColorIndex])
        }
        button.setOnLongClickListener {
            isDrawing = !isDrawing
            drawView.setDrawingEnabled(isDrawing)
            true
        }

        val buttonParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        buttonParams.gravity = Gravity.TOP or Gravity.START
        buttonParams.x = 100
        buttonParams.y = 200

        windowManager.addView(button, buttonParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.removeView(drawView)
        windowManager.removeView(button)
    }
}
