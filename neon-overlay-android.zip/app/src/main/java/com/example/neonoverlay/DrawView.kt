package com.example.neonoverlay

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class DrawView(context: Context) : View(context) {
    private val path = Path()
    private var paint = Paint().apply {
        color = Color.CYAN
        style = Paint.Style.STROKE
        strokeWidth = 20f
        isAntiAlias = true
        maskFilter = BlurMaskFilter(15f, BlurMaskFilter.Blur.NORMAL)
    }
    private var isDrawing = true

    fun setPenColor(color: Int) {
        paint.color = color
        invalidate()
    }

    fun setDrawingEnabled(enabled: Boolean) {
        isDrawing = enabled
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawPath(path, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isDrawing) return false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> path.moveTo(event.x, event.y)
            MotionEvent.ACTION_MOVE -> path.lineTo(event.x, event.y)
        }
        invalidate()
        return true
    }
}
